#!/system/bin/sh
ver=5.1
dev=@HenVx
epep=com.dts.freefireth
epepmax=com.dts.freefiremax
pubg=com.tencent.ig
mlbb=com.mobile.legends
hwag=com.mobilelegends.hwag
mlol=com.garena.game.bc
kntl=com.netease.racerna
g=com.miHoYo.GenshinImpact
echo ""
echo "
█▄░█ █░█ █▀ ▄▀█ █▄░█ ▀█▀ ▄▀█ █▀█ ▄▀█
█░▀█ █▄█ ▄█ █▀█ █░▀█ ░█░ █▀█ █▀▄ █▀█"
sleep 2
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 𝗔𝗯𝗼𝘂𝘁 ] "
echo "Developer : ${dev} "
echo "Version : ${ver} "
echo "Reborn Version "
echo ""
echo ""
sleep 3
echo "[ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼 ]"
echo ""
sleep 0.5
echo "DEVICE=$(getprop ro.product.model) "
sleep 1
echo "BRAND=$(getprop ro.product.system.brand) "
sleep 1
echo "MODEL=$(getprop ro.build.product) "
sleep 1
echo "KERNEL=$(uname -r) "
sleep 1
echo "GPU INFO=$(getprop ro.hardware.egl) "
sleep 1
echo "CPU INFO=$(getprop ro.hardware) "
echo ""
sleep 2
echo "[ 𝗦𝘂𝗽𝗽𝗼𝗿𝘁 𝗠𝗲 ]"
sleep 0.5
echo " Resource: https://t.me/HenVx1  "
sleep 0.5
echo " Discussion: https://t.me/HenVx10 "
sleep 2
echo ""
echo "🇮🇩Wait a moment to install tweaks🇮🇩"
sleep 5
echo "[■□□□□□□□□□]  "
sleep 2
echo "[■■□□□□□□□□]  "
sleep 2
echo "[■■■□□□□□□□]  "
sleep 2
echo "[■■■■□□□□□□]  "
sleep 2
echo "[■■■■■□□□□□]  "
sleep 2
echo "[■■■■■■□□□□]  "
sleep 2
echo "[■■■■■■■□□□]  "
sleep 2
echo "[■■■■■■■■□□]  "
sleep 2
echo "[■■■■■■■■■□] "
sleep 8
echo "[■■■■■■■■■■] "
sleep 0.5
echo "🇮🇩Successfully applied tweaks to system🇮🇩 "
echo ""
sleep 2

#Other Tweaks
(
setprop debug.egl.force_msaa false
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_smaa false
setprop debug.egl.force_txaa false
setprop debug.cpurend.vsync false
setprop debug.kill_allocating_task 0
setprop debug.overlayui.enable 1
setprop debug.hwui.texture_cache_size 0
setprop debug.force_rtl false
setprop debug.hw2d.force true
setprop debug.hw3d.force true
setprop debug.hwui.render_quality high
setprop debug.egl.profiler 0
setprop debug.egl.log_config 0
setprop debug.surface_flinger.vsync_sf_event_phase_offset_ns 0
setprop debug.systemuicompilerfilter speed
setprop debug.hwui.render_priority 1
setprop log.tag.ALL S
setprop log.tag.APM_AudioPolicyManager S
setprop log.tag.stats_log S
setprop log.tag.GAv4 ""
setprop log.tag.FA ""
setprop log.tag.FA-SVC ""
setprop log.tag.SQLiteLog ""
setprop log.tag.SQLiteStatements ""
setprop log.tag.MParticle ""
settings put global activity_manager_constantsmax_cached_processes=1024
settings put system pointer_speed 7
settings put global max_cached_processes 22900
settings put global background_settle_time 0
settings put global fgservice_min_shown_time 0
settings put global fgservice_min_report_time 0
settings put global fgservice_screen_on_before_time 0
settings put global fgservice_screen_on_after_time 0
settings put global content_provider_retain_time 0
settings put global gc_timeout 0
settings put global full_pss_min_interval 0
settings put global full_pss_lowered_interval 0
settings put global power_check_interval 0
settings put global power_check_max_cpu_1 0
settings put global power_check_max_cpu_2 0
settings put global power_check_max_cpu_3 0
am kill-all
)> /dev/null 2>&1
(
am force-stop com.android.providers.media
am force-stop com.android.providers.media.module
am force-stop com.google.android.gms/.kids.account.activities.RegisterProfileOwnerActivity
am force-stop com.google.android.gms/.kids.account.receiver.ProfileOwnerReceiver
am force-stop com.google.android.gms/.kids.chimera.AccountChangeReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.AccountSetupCompletedReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.AccountSetupServiceProxy
am force-stop com.google.android.gms/.kids.chimera.DeviceTimeAndDateChangeReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.InternalEventReceiverLmpProxy
am force-stop com.google.android.gms/.kids.chimera.InternalEventReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.KidsApiServiceProxy
am force-stop com.google.android.gms/.kids.chimera.KidsDataProviderProxy
am force-stop com.google.android.gms/.kids.chimera.KidsDataSyncServiceProxy
am force-stop com.google.android.gms/.kids.chimera.KidsServiceProxy
am force-stop com.google.android.gms/.kids.chimera.LocationModeChangedReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.LongRunningServiceProxy
am force-stop com.google.android.gms/.kids.chimera.PackageChangedReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.SlowOperationServiceProxy
am force-stop com.google.android.gms/.kids.chimera.SystemEventReceiverProxy
am force-stop com.google.android.gms/.kids.chimera.TimeoutsSystemAlertServiceProxy
am force-stop com.google.android.gms/.kids.common.sync.ManualSyncReceiver
am force-stop com.google.android.gms/.kids.creation.activities.FamilyCreationActivity
am force-stop com.google.android.gms/.kids.device.RingService
am force-stop com.google.android.gms/.location.copresence.GcmBroadcastReceiver
am force-stop com.google.android.gms/.location.reporting.service.GcmBroadcastReceiver
am force-stop com.google.android.gms/.measurement.PackageMeasurementTaskService
am force-stop com.google.android.gms/.measurement.service.MeasurementBrokerService
am force-stop com.google.android.gms/.nearby.bootstrap.service.NearbyBootstrapService
am force-stop com.google.android.gms/.nearby.connection.service.NearbyConnectionsAndroidService
am force-stop com.google.android.gms/.nearby.connection.service.NearbyConnectionsAsyncService
am force-stop com.google.android.gms/.nearby.messages.NearbyMessagesBroadcastReceiver
am force-stop com.google.android.gms/.nearby.messages.service.NearbyMessagesService
am force-stop com.google.android.gms/.nearby.messages.settings.NearbyMessagesAppOptInActivity
am force-stop com.google.android.gms/.nearby.settings.NearbyAccessActivity
am force-stop com.google.android.gms/.nearby.settings.NearbyAppUninstallReceiver
am force-stop com.google.android.gms/.nearby.settings.NearbySettingsActivity
am force-stop com.google.android.gms/.nearby.sharing.service.NearbySharingService
am force-stop com.google.android.gms/.perfprofile.uploader.PerfProfileCollectorService
am force-stop com.google.android.gms/.perfprofile.uploader.RequestPerfProfileCollectionService
am force-stop com.google.android.gms/.phenotype.receiver.PhenotypeBroadcastReceiver
am force-stop com.google.android.gms/.phenotype.service.PhenotypeCommitService
am force-stop com.google.android.gms/.phenotype.service.PhenotypeIntentService
am force-stop com.google.android.gms/.phenotype.service.sync.PhenotypeConfigurator
am force-stop com.google.android.gms/.phenotype.service.util.PhenotypeDebugService
am force-stop com.google.android.gms/.photos.InitializePhotosIntentReceiver
am force-stop com.google.android.gms/.photos.autobackup.AutoBackupWorkService
am force-stop com.google.android.gms/.photos.autobackup.service.AutoBackupService
am force-stop com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsActivity
am force-stop com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsRedirectActivity
am force-stop com.google.android.gms/.photos.autobackup.ui.LocalFoldersBackupSettings
pm disable com.google.android.gms/.photos.autobackup.ui.promo.AutoBackupPromoActivity
pm disable com.google.android.gms/.plus.activity.AccountSignUpActivity
pm disable com.google.android.gms/.plus.apps.ListAppsActivity
pm disable com.google.android.gms/.plus.apps.ManageAppActivity
pm disable com.google.android.gms/.plus.apps.ManageDeviceActivity
pm disable com.google.android.gms/.plus.apps.ManageMomentActivity
pm disable com.google.android.gms/.plus.audience.AclSelectionActivity
pm disable com.google.android.gms/.plus.audience.AudienceSearchActivity
pm disable com.google.android.gms/.plus.audience.CircleCreationActivity
pm disable com.google.android.gms/.plus.audience.CircleSelectionActivity
pm disable com.google.android.gms/.plus.audience.FaclSelectionActivity
pm disable com.google.android.gms/.plus.audience.UpdateActionOnlyActivity
pm disable com.google.android.gms/.plus.audience.UpdateCirclesActivity
pm disable com.google.android.gms/.plus.circles.AddToCircleConsentActivity
pm disable com.google.android.gms/.plus.oob.PlusActivity
pm disable com.google.android.gms/.plus.oob.UpgradeAccountActivity
pm disable com.google.android.gms/.plus.oob.UpgradeAccountInfoActivity
pm disable com.google.android.gms/.plus.plusone.PlusOneActivity
pm disable com.google.android.gms/.plus.provider.PlusProvider
pm disable com.google.android.gms/.plus.service.DefaultIntentService
pm disable com.google.android.gms/.plus.service.ImageIntentService
pm disable com.google.android.gms/.plus.service.OfflineActionSyncAdapterService
pm disable com.google.android.gms/.plus.service.PlusService
pm disable com.google.android.gms/.plus.sharebox.AddToCircleActivity
pm disable com.google.android.gms/.plus.sharebox.ReplyBoxActivity
pm disable com.google.android.gms/.plus.sharebox.ShareBoxActivity
pm disable com.google.android.gms/.pseudonymous.service.PseudonymousIdIntentService
pm disable com.google.android.gms/.pseudonymous.service.PseudonymousIdService
pm disable com.google.android.gms/.social.location.GservicesBroadcastReceiver
pm disable com.google.android.gms/.update.SystemUpdateService$ActiveReceiver
am force-stop com.google.android.gms/.update.SystemUpdateService$OtaPolicyReceiver
am force-stop com.google.android.gms/.update.SystemUpdateService$Receiver
am force-stop com.google.android.gms/.update.SystemUpdateService$SecretCodeReceiver
am force-stop com.google.android.gms/.usagereporting.service.UsageReportingService
am force-stop com.google.android.gms/.usagereporting.settings.UsageReportingActivity
am force-stop com.google.android.gms/.wallet.service.analytics.AnalyticsIntentService
am force-stop com.google.android.gms/.wifi.gatherer2.receiver.GoogleAccountChangeReceiver
am force-stop com.google.android.gms/.wifi.gatherer2.receiver.WifiStateChangeReceiver
am force-stop com.google.android.gms/.wifi.gatherer2.service.GcmReceiverService
am force-stop com.google.android.gms/.wifi.gatherer2.service.KeyManagerServce
am force-stop com.google.android.gms/.wifi.gatherer2.service.WifiUpdateRetryTaskService
am force-stop com.google.android.gms/com.google.android.contextmanager.service.ContextManagerService
am force-stop com.google.android.gms/com.google.android.contextmanager.systemstate.SystemStateReceiver
am force-stop com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
am force-stop com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitor
am force-stop com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitorIntentService
am force-stop com.google.android.gms/com.google.android.location.activity.HardwareArProviderService
am force-stop  com.google.android.gms/com.google.android.location.copresence.GcmRegistrationReceiver
am force-stop com.google.android.gms/com.google.android.location.copresence.GservicesBroadcastReceiver
am force-stop com.google.android.gms/com.google.android.location.fused.FusedLocationService
am force-stop com.google.android.gms/com.google.android.location.fused.service.FusedProviderService
)> /dev/null 2>&1
(
cmd thermalservice override-status 0
cmd power set-fixed-performance-mode-enabled true
)> /dev/null 2>&1
{
for app in $(cmd package list packages -3 | cut -f 2 -d ":"); do
if [[ ! "$app" == "me.piebridge.brevent" ]]; then
cmd activity force-stop "$app"
cmd activity kill "$app"
fi
done
} > /dev/null 2>&1
(
cmd game mode performance ${epep}
cmd game mode performance ${pubg}
cmd game mode performance ${mlbb}
cmd game mode performance ${hwag}
cmd game mode performance ${epepmax}
cmd game mode performance ${mlol}
cmd game mode performance ${kntl}
cmd game mode performance ${g}
appops set ${epep} RUN_IN_BACKGROUND allow
appops set ${pubg} RUN_IN_BACKGROUND allow
appops set ${mlbb} RUN_IN_BACKGROUND allow
appops set ${hwag} RUN_IN_BACKGROUND allow
appops set ${epepmax} RUN_IN_BACKGROUND allow
appops set ${mlol} RUN_IN_BACKGROUND allow
appops set ${kntl} RUN_IN_BACKGROUND allow
appops set ${g} RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f ${epep}
cmd package compile -m everything-profile -f ${pubg}
cmd package compile -m everything-profile -f ${mlbb}
cmd package compile -m everything-profile -f ${epepmax}
cmd package compile -m everything-profile -f ${hwag}
cmd package compile -m everything-profile -f ${kntl}
cmd package compile -m everything-profile -f ${g}
cmd package compile -m speed --secondary-dex -f ${epep}
cmd package compile -m speed --secondary-dex -f ${pubg}
cmd package compile -m speed --secondary-dex -f ${mlbb}
cmd package compile -m speed --secondary-dex -f ${epepmax}
cmd package compile -m speed --secondary-dex -f ${hwag}
cmd package compile -m speed --secondary-dex -f ${g}
cmd package compile -m speed --check-prof false -f ${epep}
cmd package compile -m speed --check-prof false -f ${pubg}
cmd package compile -m speed --check-prof false -f ${mlbb}
cmd package compile -m speed --check-prof false -f ${epepmax}
cmd package compile -m speed --check-prof false -f ${hwag}
cmd package compile -m speed --check-prof false -f ${g}
cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.gms START_FOREGROUND ignore
cmd appops set com.google.android.gms INSTANT_APP_START_FOREGROUND ignore
cmd appops set com.google.android.ims RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.ims RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.ims START_FOREGROUND ignore
cmd appops set com.google.android.ims INSTANT_APP_START_FOREGROUND ignore
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
dumpsys deviceidle whitelist +com.android.systemui
dumpsys power set_sampling_rate 0
cmd activity kill-all
am kill-all
rm -f /storage/emulated/0/Pictures/.thumbnails/*
rm -f /storage/emulated/0/Movies/.thumbnails/*
rm -f /data/local/traces/*
device_config put activity_manager power_check_max_cpu_1 0
device_config put activity_manager power_check_max_cpu_2 0
device_config put activity_manager power_check_max_cpu_3 0
device_config put activity_manager power_check_max_cpu_4 0
device_config put activity_manager min_frame_duration_ms 8
device_config put activity_manager max_phantom_processes 0
device_config put activity_manager max_cached_processes 256
device_config put activity_manager set_sync_disabled_for_tests persistent
device_config put activity_manager max_empty_time_millis 43200000
device_config put activity_manager window_focus_timeout 500
device_config put activity_manager render_thread_priority FORCECOPY
device_config put activity_manager foreground_service_max_memory_kb 500
device_config put activity_manager background_service_max_memory_kb 250
device_config put activity_manager free_memory_percent_for_background_processes 10
device_config put activity_manager free_memory_percent_for_foreground_processes 20
device_config put activity_manager foreground_service_keep_alive_time_ms 10000
device_config put activity_manager background_service_keep_alive_time_ms 5000
)> /dev/null 2>&1
